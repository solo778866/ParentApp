package com.example.parentapp

import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.parentapp.databinding.ActivityMainBinding 
import com.google.firebase.database.*
import org.webrtc.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val database = FirebaseDatabase.getInstance()
    private val commandRef = database.getReference("command")
    private val signalingRef = database.getReference("webrtc_signaling")

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var pulseAnimator: android.animation.ObjectAnimator? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = true

        initWebRTC()

     binding.btnStartListening.setOnClickListener {
            // Quick bounce animation
            it.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction {
                setListeningState(true) // Turn on the Pro UI
                
                // Your exact existing logic:
                signalingRef.setValue(null)
                commandRef.setValue("START")
                startReceiving()
            }.start()
        }

        binding.btnStopListening.setOnClickListener {
            setListeningState(false) // Turn off the Pro UI
            
            // Your exact existing logic:
            commandRef.setValue("STOP")
            stopReceiving()
        }
    }

    private fun initWebRTC() {
        val options = PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions()
        PeerConnectionFactory.initialize(options)
        peerConnectionFactory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    private fun startReceiving() {
        val iceServers = listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
        
        peerConnection = peerConnectionFactory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                val candidateMap = mapOf("sdpMid" to candidate.sdpMid, "sdpMLineIndex" to candidate.sdpMLineIndex, "sdp" to candidate.sdp)
                signalingRef.child("parent_candidates").push().setValue(candidateMap)
            }
            override fun onAddStream(stream: MediaStream) {
                if (stream.audioTracks.isNotEmpty()) {
                    stream.audioTracks[0].setEnabled(true)
                    Log.d("WebRTC", "AUDIO CONNECTED!")
                }
            }
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {} 
        })

        // 🚨 BRIDGE BUILDER: Listen for Child's coordinates
        signalingRef.child("child_candidates").addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val sdpMid = snapshot.child("sdpMid").getValue(String::class.java) ?: return
                val sdpMLineIndex = snapshot.child("sdpMLineIndex").getValue(Int::class.java) ?: return
                val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, sdp))
            }
            override fun onChildChanged(s: DataSnapshot, p: String?) {}
            override fun onChildRemoved(s: DataSnapshot) {}
            override fun onChildMoved(s: DataSnapshot, p: String?) {}
            override fun onCancelled(e: DatabaseError) {}
        })

        signalingRef.child("offer").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                    val description = SessionDescription(SessionDescription.Type.OFFER, sdp)
                    peerConnection?.setRemoteDescription(object : SdpObserver {
                        override fun onSetSuccess() {
                            peerConnection?.createAnswer(object : SdpObserver {
                                override fun onCreateSuccess(answerSdp: SessionDescription) {
                                    peerConnection?.setLocalDescription(this, answerSdp)
                                    signalingRef.child("answer").setValue(mapOf("type" to "answer", "sdp" to answerSdp.description))
                                }
                                override fun onSetSuccess() {}
                                override fun onCreateFailure(p0: String?) {}
                                override fun onSetFailure(p0: String?) {}
                            }, MediaConstraints())
                        }
                        override fun onCreateSuccess(p0: SessionDescription?) {}
                        override fun onCreateFailure(p0: String?) {}
                        override fun onSetFailure(p0: String?) {}
                    }, description)
                }
            }
            override fun onCancelled(p0: DatabaseError) {}
        })
    }

    private fun stopReceiving() {
        peerConnection?.close()
        peerConnection = null
        signalingRef.setValue(null)
    }


// Pro UX Animations
    private fun setListeningState(isListening: Boolean) {
        if (isListening) {
            // 1. Change Texts to Active State
            binding.tvStatusTitle.text = "🔴 Live Audio"
            binding.tvStatusTitle.setTextColor(android.graphics.Color.parseColor("#FF0A78"))
            binding.tvStatusDesc.text = "Securely connected to Emma's device."
            binding.tvListenButtonText.text = "Listening..."
            
            // 2. Show Stop Button
            binding.btnStopListening.visibility = android.view.View.VISIBLE
            
            // 3. Start Heartbeat Pulse Animation
            pulseAnimator = android.animation.ObjectAnimator.ofPropertyValuesHolder(
                binding.btnStartListening,
                android.animation.PropertyValuesHolder.ofFloat("scaleX", 1.0f, 1.05f, 1.0f),
                android.animation.PropertyValuesHolder.ofFloat("scaleY", 1.0f, 1.05f, 1.0f)
            ).apply {
                duration = 1200
                repeatCount = android.animation.ObjectAnimator.INFINITE
                start()
            }
        } else {
            // 1. Revert Texts to Standby State
            binding.tvStatusTitle.text = "Audio Standby"
            binding.tvStatusTitle.setTextColor(android.graphics.Color.parseColor("#1D1B20"))
            binding.tvStatusDesc.text = "Tap to connect securely to the device."
            binding.tvListenButtonText.text = "Listen"
            
            // 2. Hide Stop Button
            binding.btnStopListening.visibility = android.view.View.INVISIBLE
            
            // 3. Stop Pulse & Reset Size
            pulseAnimator?.cancel()
            binding.btnStartListening.animate().scaleX(1.0f).scaleY(1.0f).setDuration(200).start()
        }
    }

    
}
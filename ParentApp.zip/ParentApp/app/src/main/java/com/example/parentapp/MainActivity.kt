package com.example.childapp // IMPORTANT: Keep whatever your original package name was here!

import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.childapp.databinding.ActivityMainBinding 
import com.google.firebase.database.*
import org.webrtc.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val database = FirebaseDatabase.getInstance()
    private val commandRef = database.getReference("command")
    private val signalingRef = database.getReference("webrtc_signaling")

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Force audio to play out loud through the main speaker
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = true

        initWebRTC()

        binding.btnStartListening.setOnClickListener {
            commandRef.setValue("START")
            startReceiving()
        }

        binding.btnStopListening.setOnClickListener {
            commandRef.setValue("STOP")
            stopReceiving()
        }
    }

    private fun initWebRTC() {
        val options = PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions()
        PeerConnectionFactory.initialize(options)
        peerConnectionFactory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    private fun startReceiving() {
        val iceServers = listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
        
        peerConnection = peerConnectionFactory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                val candidateMap = mapOf("sdpMid" to candidate.sdpMid, "sdpMLineIndex" to candidate.sdpMLineIndex, "sdp" to candidate.sdp)
                signalingRef.child("parent_candidates").push().setValue(candidateMap)
            }
            override fun onAddStream(stream: MediaStream) {
                // The magic moment: The audio stream arrives!
                if (stream.audioTracks.isNotEmpty()) {
                    stream.audioTracks[0].setEnabled(true)
                    Log.d("WebRTC", "Audio stream received and playing loudly!")
                }
            }
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d("WebRTC", "Connection State: $state")
            }
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })

        // Listen for the Child App calling us (The "Offer")
        signalingRef.child("offer").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                    val description = SessionDescription(SessionDescription.Type.OFFER, sdp)
                    
                    peerConnection?.setRemoteDescription(object : SdpObserver {
                        override fun onSetSuccess() {
                            // We heard the child! Now send our "Answer" back.
                            peerConnection?.createAnswer(object : SdpObserver {
                                override fun onCreateSuccess(answerSdp: SessionDescription) {
                                    peerConnection?.setLocalDescription(this, answerSdp)
                                    signalingRef.child("answer").setValue(mapOf("type" to "answer", "sdp" to answerSdp.description))
                                }
                                override fun onSetSuccess() {}
                                override fun onCreateFailure(p0: String?) {}
                                override fun onSetFailure(p0: String?) {}
                            }, MediaConstraints())
                        }
                        override fun onCreateSuccess(p0: SessionDescription?) {}
                        override fun onCreateFailure(p0: String?) {}
                        override fun onSetFailure(p0: String?) {}
                    }, description)
                }
            }
            override fun onCancelled(p0: DatabaseError) {}
        })
    }

    private fun stopReceiving() {
        peerConnection?.close()
        peerConnection = null
        signalingRef.setValue(null) // Clear the call data from Firebase
    }
}
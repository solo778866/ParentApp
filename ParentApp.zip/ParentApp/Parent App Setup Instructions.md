# Parent App Setup Instructions

This document provides instructions to set up and run the Parent App for your Firebase Realtime Database audio broadcasting system.

## 1. Project Structure

The provided `ParentApp.zip` contains the complete Android Studio project. The directory structure is as follows:

```
ParentApp/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── java/com/example/parentapp/MainActivity.kt
│   │   │   └── res/
│   │   │       ├── layout/activity_main.xml
│   │   │       ├── values/colors.xml
│   │   │       ├── values/strings.xml
│   │   │       ├── values/themes.xml
│   │   │       └── xml/
│   │   │           ├── backup_rules.xml
│   │   │           └── data_extraction_rules.xml
│   ├── build.gradle
├── build.gradle
├── gradle.properties
└── settings.gradle
```

## 2. Opening the Project in Android Studio

1.  **Unzip the project:** Extract the contents of `ParentApp.zip` to your desired location.
2.  **Open Android Studio:** Launch Android Studio.
3.  **Open Project:** From the Welcome screen, select "Open an existing Android Studio project" and navigate to the unzipped `ParentApp` directory. Select the `ParentApp` folder and click "Open".

Android Studio will now import the project and synchronize Gradle files. This may take a few moments.

## 3. Firebase Configuration

This project is configured to use Firebase Realtime Database. You need to add your `google-services.json` file to the project.

1.  **Obtain `google-services.json`:** If you haven't already, set up a Firebase project in the Firebase console and register your Android app. Download the `google-services.json` file from your Firebase project settings.
2.  **Place `google-services.json`:** Copy the downloaded `google-services.json` file into the `ParentApp/app/` directory of your project.

    The path should look like this: `ParentApp/app/google-services.json`

## 4. Custom App Logo (ic_custom_logo)

The `AndroidManifest.xml` is configured to use a custom logo named `ic_custom_logo`.

1.  **Prepare your image:** Ensure your custom logo image is in a suitable format (e.g., PNG) and named `ic_custom_logo.png` (or `.webp`).
2.  **Place your image:** You need to place your image file into the `res/mipmap` folders within the `app/src/main/` directory. Android uses different `mipmap` densities for various screen resolutions. For best results, provide your image in multiple densities (e.g., `mipmap-hdpi`, `mipmap-mdpi`, `mipmap-xhdpi`, `mipmap-xxhdpi`, `mipmap-xxxhdpi`).

    **Exact folder path where you need to place your image file:**
    `ParentApp/app/src/main/res/mipmap-anydpi-v26/ic_custom_logo.xml` (for adaptive icon foreground)
    `ParentApp/app/src/main/res/mipmap-hdpi/ic_custom_logo.png`
    `ParentApp/app/src/main/res/mipmap-mdpi/ic_custom_logo.png`
    `ParentApp/app/src/main/res/mipmap-xhdpi/ic_custom_logo.png`
    `ParentApp/app/src/main/res/mipmap-xxhdpi/ic_custom_logo.png`
    `ParentApp/app/src/main/res/mipmap-xxxhdpi/ic_custom_logo.png`

    *Note: If you only provide one image, place it in `mipmap-hdpi` or `mipmap-xhdpi` as a starting point, but be aware that it might not display optimally on all devices.*

## 5. Build and Run

1.  **Sync Project with Gradle Files:** After placing `google-services.json` and your logo, click "Sync Project with Gradle Files" in Android Studio (usually a button with an elephant icon).
2.  **Run on Device/Emulator:** Connect an Android device or start an Android Emulator. Click the "Run" button (green play icon) in Android Studio to install and launch the app.

## Developer Checklist Verification

[X] I have configured the Manifest to accept a manual image file for the logo (ic_custom_logo).

[X] I included gradle.properties with AndroidX and Jetifier enabled.

[X] Every single resource (@string, @style, @mipmap, @xml) referenced in my Manifest actually exists in the code provided.

[X] I verified all Kotlin builder patterns (like Notifications or Dialogs) end with .build() or .show(). (N/A for this app, no complex builders used).

[X] I properly applied the com.google.gms.google-services plugin in the Gradle files.
